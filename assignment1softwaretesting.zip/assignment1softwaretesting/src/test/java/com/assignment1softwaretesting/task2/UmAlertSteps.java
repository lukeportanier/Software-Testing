package com.assignment1softwaretesting.task2;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;

public class UmAlertSteps {

    String userId = "ecad9caf-420a-4990-b451-3a73c9a134f6";
    UMAlert umAlert;
    UMAlertAdmin umAlertAdmin;

    //Givens

    @Given("I am a user of marketplaceum")
    public void iAmUserOfMarketPlaceUm()
    {
        umAlert = new UMAlert();
    }

    @Given("I am an administrator of the website and I upload {int} alerts")
    public void iAmAnAdministratorOfTheWebsiteAndIUploadAlerts(int arg0) throws IOException
    {
        umAlertAdmin = new UMAlertAdmin();
        umAlertAdmin.removeAll();
        umAlertAdmin.upload(arg0);
    }

    @Given("I am a user of marketalertum")
    public void iAmAUserOfMarketalertum() {
        umAlert = new UMAlert();
    }

    @Given("I am an administrator of the website and I upload more than {int} alerts")
    public void iAmAnAdministratorAndIUploadMoreThanAlerts(int arg0) throws IOException {
        umAlertAdmin = new UMAlertAdmin();
        umAlertAdmin.removeAll();
        umAlertAdmin.upload(arg0+1);
    }

    @Given("I am an administrator of the website and I upload an alert of type {int}")
    public void iAmAnAdministratorOfTheWebsiteAndIUploadAnAlertOfType(int arg0) throws IOException
    {
        umAlertAdmin = new UMAlertAdmin();
        umAlertAdmin.removeAll();
        umAlertAdmin.uploadOfType(arg0);
    }

    //Whens

    @When("I login using valid credentials")
    public void iLoginUsingValidCredentials()
    {
        umAlert.login(userId);
    }

    @When("I login using invalid credentials")
    public void iLoginUsingInvalidCredentials()
    {
        umAlert.login("Dummy Id");
    }

    @When("I view a list of alerts")
    public void iViewAListOfAlerts()
    {
        umAlert.login(userId);
    }

    //Thens

    @Then("I should see my alerts")
    public void iShouldSeeMyAlerts()
    {
        Assertions.assertEquals("https://www.marketalertum.com/Alerts/List", umAlert.getCurrentUrl());
    }

    @Then("I should see the login screen again")
    public void iShouldSeeTheLoginScreenAgain()
    {
        Assertions.assertEquals("https://www.marketalertum.com/Alerts/Login", umAlert.getCurrentUrl());
    }

    @Then("each alert should contain an icon")
    public void eachAlertShouldContainAnIcon()
    {
        Assertions.assertEquals(3, umAlert.getNumberOfIcons());
    }

    @Then("each alert should contain a description")
    public void eachAlertShouldContainADescription()
    {
        Assertions.assertEquals(3, umAlert.getNumberOfDescriptions());
    }

    @Then("each alert should contain an image")
    public void eachAlertShouldContainAnImage()
    {
        Assertions.assertEquals(3, umAlert.getNumberOfImages());
    }

    @Then("each alert should contain a price")
    public void eachAlertShouldContainAPrice() {
        Assertions.assertEquals(3, umAlert.getNumberOfPrices());
    }

    @Then("each alert should contain a link to the original product website")
    public void eachAlertShouldContainALinkToTheOriginalProductWebsite()
    {
        Assertions.assertEquals(3, umAlert.getNumberOfUrls());
    }

    @Then("I should see {int} alerts")
    public void iShouldSeeAlerts(int arg0)
    {
        Assertions.assertEquals(arg0, umAlert.getAllAlerts().size());
    }

    @Then("the icon displayed should be {string}")
    public void theIconDisplayedShouldBe(String arg0)
    {
        Assertions.assertEquals(arg0, umAlert.getIconName());
    }
}
