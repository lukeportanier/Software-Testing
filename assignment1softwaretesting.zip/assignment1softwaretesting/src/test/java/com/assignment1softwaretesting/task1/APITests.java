package com.assignment1softwaretesting.task1;

import com.assignment1softwaretesting.task1.spies.APIManagerSpy;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class APITests
{

    @BeforeEach
    public void setup()
    {

    }

    @Test
    public void testPostRequest() throws IOException {
        //Setup
        APIManagerSpy apiManager = new APIManagerSpy();
        UMAlertAPI api = new UMAlertAPI();

        api.setApiManager(apiManager);

        Product dummyProduct = new Product(6,"prodName", "prodDesc", "prodURL", "prodImage", 10000);
        String testJsonString = dummyProduct.stringify();

        //Exercise
        api.postRequest(testJsonString);

        //Verify
        Assertions.assertEquals(1, apiManager.numCallsToPostRequest);

    }

    @Test
    public void testDeleteRequest() throws IOException {

        //Setup
        APIManagerSpy apiManager = new APIManagerSpy();
        UMAlertAPI api = new UMAlertAPI();

        api.setApiManager(apiManager);

        //Exercise
        api.deleteRequest();

        //Verify
        Assertions.assertEquals(1, apiManager.numCallsToDeleteRequest);


    }



}
