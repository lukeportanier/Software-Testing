package com.assignment1softwaretesting.task1;

import com.assignment1softwaretesting.task1.stubs.ListEmpty;
import com.assignment1softwaretesting.task1.stubs.ListNotEmpty;
import com.assignment1softwaretesting.task1.stubs.SearchNotFound;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.assignment1softwaretesting.task1.stubs.SearchFound;

public class WebScraperTests
{
    private WebScraper scraper;

    @BeforeEach
    public void setup()
    {
        scraper = new WebScraper();
    }


    @Test
    public void successfulSearchForIphone()//SearchYieldsResults
    {
        //Setup
        scraper.setSearchManager(new SearchFound());

        //Exercise
        boolean searchResult = scraper.search();

        //Verify
        Assertions.assertTrue(searchResult);

    }

    @Test
    public void unsuccessfulSearchForIphone()//Search yields no results
    {
        //Setup
        scraper.setSearchManager(new SearchNotFound());

        //Exercise
        boolean searchResult = scraper.search();

        //Verify
        Assertions.assertFalse(searchResult);
    }

    @Test
    public void getListOfProductsWhereListNotEmpty()
    {
        //Setup
        scraper.setResultManager(new ListNotEmpty());

        //Exercise
        boolean result = scraper.getListOfProducts();

        //Verify
        Assertions.assertTrue(result);

    }

    @Test
    public void getListOfProductsWhereListEmpty()
    {
        //Setup
        scraper.setResultManager(new ListEmpty());

        //Exercise
        boolean result = scraper.getListOfProducts();

        //Verify
        Assertions.assertFalse(result);

    }

}
