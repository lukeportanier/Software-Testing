package com.assignment1softwaretesting.task1.stubs;

import com.assignment1softwaretesting.task1.managerinterfaces.SearchManager;

public class SearchNotFound implements SearchManager
{
    @Override
    public boolean checkIfSearchSucceeded() {
        return false;
    }
}
