package com.assignment1softwaretesting.task1.stubs;

import com.assignment1softwaretesting.task1.managerinterfaces.ResultManager;

public class ListNotEmpty implements ResultManager {

    @Override
    public boolean checkIfListNotEmpty() {
        return true;
    }
}
