package com.assignment1softwaretesting.task1.spies;

import com.assignment1softwaretesting.task1.managerinterfaces.APIManager;

public class APIManagerSpy implements APIManager {

    public int numCallsToPostRequest = 0;
    public int numCallsToDeleteRequest = 0;

    @Override
    public void postRequest(String productJsonString)
    {
        numCallsToPostRequest++;
    }

    @Override
    public void deleteRequest()
    {
        numCallsToDeleteRequest++;
    }
}
