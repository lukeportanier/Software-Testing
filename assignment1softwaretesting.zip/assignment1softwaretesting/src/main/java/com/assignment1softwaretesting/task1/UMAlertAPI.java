package com.assignment1softwaretesting.task1;

import com.assignment1softwaretesting.task1.managerinterfaces.*;

import java.io.IOException;

public class UMAlertAPI implements APIManager
{

    protected APIManager apiManager;

    @Override
    public void postRequest(String productJsonString) throws IOException {
        apiManager.postRequest(productJsonString);
    }

    @Override
    public void deleteRequest() throws IOException {
        apiManager.deleteRequest();
    }

    //Manager Setters
    public void setApiManager(APIManager apiManager)
    {
        this.apiManager = apiManager;
    }

}
