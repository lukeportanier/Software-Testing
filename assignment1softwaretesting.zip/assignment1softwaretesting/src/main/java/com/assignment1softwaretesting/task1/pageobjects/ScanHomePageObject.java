package com.assignment1softwaretesting.task1.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ScanHomePageObject
{

    WebDriver driver;

    public ScanHomePageObject(WebDriver driver)
    {
        this.driver = driver;
    }

    public String search(String product)
    {
        //Locate Search Bar
        WebElement searchbar = driver.findElement(By.id("search"));
        searchbar.sendKeys("iphone");

        //Submit
        searchbar.submit();

        //Get Title
        return driver.getTitle();
    }

}
