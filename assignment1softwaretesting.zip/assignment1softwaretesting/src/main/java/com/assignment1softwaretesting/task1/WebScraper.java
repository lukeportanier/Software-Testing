package com.assignment1softwaretesting.task1;

import com.assignment1softwaretesting.task1.managerinterfaces.ResultManager;
import com.assignment1softwaretesting.task1.managerinterfaces.SearchManager;

public class WebScraper
{

    protected SearchManager searchManager;
    protected ResultManager resultManager;


    public boolean search()
    {
        return searchManager != null && searchManager.checkIfSearchSucceeded();
    }

    public boolean getListOfProducts()
    {
        return resultManager != null && resultManager.checkIfListNotEmpty();
    }

    //Manager Setters
    public void setSearchManager(SearchManager searchManager)
    {
        this.searchManager = searchManager;
    }

    public void setResultManager(ResultManager resultManager)
    {
        this.resultManager = resultManager;
    }

}
