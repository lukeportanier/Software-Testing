package com.assignment1softwaretesting.task1.managerinterfaces;

public interface SearchManager
{

    boolean checkIfSearchSucceeded();

}
