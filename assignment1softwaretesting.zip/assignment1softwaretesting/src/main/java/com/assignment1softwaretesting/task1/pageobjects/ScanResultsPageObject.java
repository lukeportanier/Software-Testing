package com.assignment1softwaretesting.task1.pageobjects;

import com.assignment1softwaretesting.task1.Product;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.LinkedList;
import java.util.List;

public class ScanResultsPageObject
{

    WebDriver driver;

    public ScanResultsPageObject(WebDriver driver)
    {
        this.driver = driver;
    }

    public List<WebElement> returnAllProductResults()
    {
        List<WebElement> productSearchResults = new LinkedList<WebElement>();

        productSearchResults = driver.findElements(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[5]/div[2]/ol/li"));

        return productSearchResults;
    }

    public List<Product> getListOfProductInformation(List<WebElement> productsList)
    {
        String productName;
        String productDescription;
        String productUrl;
        String productImage;
        String productPrice;

        List<Product> productList = new LinkedList<Product>();

        for (int i=0;i<productsList.size();i++)
        {

            productName = "iphone";
            productDescription = productsList.get(i).findElement(By.className("product-item-link")).getText();
            productUrl = productsList.get(i).findElement(By.className("product-item-link")).getAttribute("href");
            productImage = productsList.get(i).findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[5]/div[2]/ol/li[1]/div/div[1]/a/span/span/img")).getAttribute("src");
            productPrice = productsList.get(i).findElement(By.className("price")).getText();

            productList.add(new Product(6, productName, productDescription, productUrl, productImage, getPriceInCents(productPrice)));

        }

        return productList;
    }


    public int getPriceInCents(String price)
    {
        String newPrice = price.replaceAll("[€.]", "");
        return Integer.parseInt(newPrice);
    }

}
