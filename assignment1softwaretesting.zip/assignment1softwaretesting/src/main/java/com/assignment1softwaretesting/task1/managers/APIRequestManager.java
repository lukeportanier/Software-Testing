package com.assignment1softwaretesting.task1.managers;

import com.assignment1softwaretesting.task1.managerinterfaces.APIManager;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class APIRequestManager implements APIManager
{
    String userId = "ecad9caf-420a-4990-b451-3a73c9a134f6";

    @Override
    public void postRequest(String productJsonString) throws IOException
    {
        URL url = new URL("https://api.marketalertum.com/Alert");
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("POST");
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Content-Type", "application/json");

        byte[] out = productJsonString.getBytes(StandardCharsets.UTF_8);

        OutputStream stream = http.getOutputStream();
        stream.write(out);

        System.out.print(http.getResponseCode() + " "+ http.getResponseMessage());
        http.disconnect();
    }

    @Override
    public void deleteRequest() throws IOException {
        URL url = new URL("https://api.marketalertum.com/Alert?userId=" + userId);
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("DELETE");

        System.out.print(http.getResponseCode() + " "+ http.getResponseMessage());
        http.disconnect();
    }
}
