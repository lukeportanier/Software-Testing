package com.assignment1softwaretesting.task1.managers;

import com.assignment1softwaretesting.task1.Product;
import com.assignment1softwaretesting.task1.managerinterfaces.ResultManager;
import com.assignment1softwaretesting.task1.pageobjects.*;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class DriverResultManager implements ResultManager
{

    WebDriver driver;
    ScanResultsPageObject scanResults;
    List<Product> productList;

    public DriverResultManager(WebDriver driver)
    {
        this.driver = driver;
        scanResults = new ScanResultsPageObject(driver);
    }

    @Override
    public boolean checkIfListNotEmpty()
    {
        productList = scanResults.getListOfProductInformation(scanResults.returnAllProductResults());
        return productList.size() > 0;
    }

    public List<Product> getProductList()
    {
        return productList;
    }
}
