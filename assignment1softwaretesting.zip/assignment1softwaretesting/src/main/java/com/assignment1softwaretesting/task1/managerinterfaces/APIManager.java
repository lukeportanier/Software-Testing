package com.assignment1softwaretesting.task1.managerinterfaces;

import java.io.IOException;

public interface APIManager
{
    void postRequest(String productJsonString) throws IOException;

    void deleteRequest() throws IOException;

}
