package com.assignment1softwaretesting.task1.managerinterfaces;

public interface ResultManager
{

    boolean checkIfListNotEmpty();

}
