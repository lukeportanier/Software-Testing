package com.assignment1softwaretesting.task1.managers;

import com.assignment1softwaretesting.task1.managerinterfaces.SearchManager;
import com.assignment1softwaretesting.task1.pageobjects.*;
import org.openqa.selenium.WebDriver;

public class DriverSearchManager implements SearchManager {

    WebDriver driver;
    ScanHomePageObject scanHome;

    public DriverSearchManager(WebDriver driver)
    {
        this.driver = driver;
        scanHome = new ScanHomePageObject(driver);
    }

    @Override
    public boolean checkIfSearchSucceeded()
    {
        String title = scanHome.search("iphone");
        return title.contains("iphone");

    }
}
