package com.assignment1softwaretesting.task1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class Product
{

    protected int alertType = 6;
    protected String heading;
    protected String description;
    protected String url;
    protected String imageUrl;
    protected String postedBy = "ecad9caf-420a-4990-b451-3a73c9a134f6";
    protected int priceInCents;

    public Product(int alertType, String productName, String productDescription, String url, String imageURL, int priceInCents)
    {
        this.alertType = alertType;
        heading = productName;
        description = productDescription;
        this.url = url;
        this.imageUrl = imageURL;
        this.priceInCents = priceInCents;
    }

    public String stringify() throws JsonProcessingException
    {
        //Turn Product to Json String
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        return ow.writeValueAsString(this);
    }

    public String getHeading()
    {
        return heading;
    }

    public String getDescription()
    {
        return description;
    }

    public String getUrl()
    {
        return url;
    }

    public String getImageUrl()
    {
        return imageUrl;
    }

    public int getPriceInCents()
    {
        return priceInCents;
    }

    public String getPostedBy()
    {
        return postedBy;
    }

    public int getAlertType(){
        return alertType;
    }

}
