package com.assignment1softwaretesting.task2.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObject
{
    WebDriver driver;

    public LoginPageObject(WebDriver driver)
    {
        this.driver = driver;
    }

    public void login(String userId)
    {
        //Locate Login Page
        WebElement loginTab = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul/li[3]/a"));
        loginTab.click();

        //Locate Input Text Field
        WebElement textField = driver.findElement(By.name("UserId"));
        textField.sendKeys(userId);

        //Submit
        textField.submit();


    }


}
