package com.assignment1softwaretesting.task2;

import com.assignment1softwaretesting.task2.pageobjects.AlertsPageObject;
import com.assignment1softwaretesting.task2.pageobjects.LoginPageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

/*
Testability comments:
1. Give id/name to navbar items to make them more easily accessible
2. Change page Title depending on which page you are on, would be easier then using the current url to use the title when fetching which page you are currently on
3. Give id/name to table row of an alert to help differentiate when getting heading, description, price etc.
 */

public class UMAlert
{
    WebDriver driver;
    LoginPageObject loginPage;
    AlertsPageObject alertPage;

    public UMAlert()
    {
        System.setProperty("webdriver.chrome.driver", "/Users/lukep/webtesting/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.marketalertum.com");

        loginPage = new LoginPageObject(driver);
        alertPage = new AlertsPageObject(driver);

    }

    public void login(String userId)
    {
        loginPage.login(userId);
    }

    public String getCurrentUrl()
    {
        return driver.getCurrentUrl();
    }


    public List<WebElement> getAllAlerts()
    {
        return driver.findElements(By.xpath("/html/body/div/main/table"));
    }

    public int getNumberOfImages()
    {
        int numOfImages = 0;
        List<WebElement> alerts = getAllAlerts();

        for (WebElement alert: alerts)
        {
            alert.findElement(By.xpath("/html/body/div/main/table/tbody/tr[2]/td/img"));
            numOfImages++;
        }

        return numOfImages;
    }

    public int getNumberOfIcons()
    {
        int numOfIcons = 0;
        List<WebElement> alerts = getAllAlerts();

        for (WebElement alert: alerts)
        {
            alert.findElement(By.xpath("/html/body/div/main/table/tbody/tr[1]/td/h4/img"));
            numOfIcons++;
        }

        return numOfIcons;

    }

    public int getNumberOfDescriptions()
    {
        int numOfDescs = 0;
        List<WebElement> alerts = getAllAlerts();

        for (WebElement alert: alerts)
        {
            alert.findElement(By.xpath("/html/body/div/main/table/tbody/tr[3]/td"));
            numOfDescs++;
        }

        return numOfDescs;
    }

    public int getNumberOfPrices()
    {
        int numOfPrices = 0;
        List<WebElement> alerts = getAllAlerts();

        for (WebElement alert: alerts)
        {
            alert.findElement(By.xpath("/html/body/div/main/table/tbody/tr[4]/td"));
            numOfPrices++;
        }

        return numOfPrices;
    }

    public int getNumberOfUrls()
    {
        int numOfUrls = 0;

        List<WebElement> alerts = getAllAlerts();

        for (WebElement alert: alerts)
        {
            alert.findElement(By.xpath("/html/body/div/main/table/tbody/tr[5]/td/a"));
            numOfUrls++;
        }

        return numOfUrls;

    }

    public String getIconName()
    {

        String iconString = alertPage.getIconName();

        return iconString;

    }




}
