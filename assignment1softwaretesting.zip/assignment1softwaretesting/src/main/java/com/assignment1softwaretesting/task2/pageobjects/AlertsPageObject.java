package com.assignment1softwaretesting.task2.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AlertsPageObject
{
    WebDriver driver;

    public AlertsPageObject(WebDriver driver)
    {
        this.driver = driver;
    }

    public String getIconName()
    {
        String iconString = "";

        WebElement icon = driver.findElement(By.xpath("/html/body/div/main/table/tbody/tr[1]/td/h4/img"));
        String iconsrc = icon.getAttribute("src");

        switch (iconsrc)
        {
            case "https://www.marketalertum.com/images/icon-car.png":
                iconString = "icon-car.png";
                break;

            case "https://www.marketalertum.com/images/icon-boat.png":
                iconString = "icon-boat.png";
                break;

            case "https://www.marketalertum.com/images/icon-property-rent.jpg":
                iconString = "icon-property-rent.png";
                break;

            case "https://www.marketalertum.com/images/icon-property-sale.jpg":
                iconString = "icon-property-sale.png";
                break;

            case "https://www.marketalertum.com/images/icon-toys.png":
                iconString = "icon-toys.png";
                break;

            case "https://www.marketalertum.com/images/icon-electronics.png":
                iconString = "icon-electronics.png";
                break;
        }

        return iconString;
    }
}
