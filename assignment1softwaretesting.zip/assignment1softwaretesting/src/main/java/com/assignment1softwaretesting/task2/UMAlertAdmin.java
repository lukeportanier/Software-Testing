package com.assignment1softwaretesting.task2;

import com.assignment1softwaretesting.task1.Product;
import com.assignment1softwaretesting.task1.UMAlertAPI;
import com.assignment1softwaretesting.task1.WebScraper;
import com.assignment1softwaretesting.task1.managers.APIRequestManager;
import com.assignment1softwaretesting.task1.managers.DriverResultManager;
import com.assignment1softwaretesting.task1.managers.DriverSearchManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;
import java.util.List;

public class UMAlertAdmin
{

    public List<Product> getProducts()
    {
        WebScraper scraper = new WebScraper();

        System.setProperty("webdriver.chrome.driver", "/Users/lukep/webtesting/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.scanmalta.com/shop/");

        DriverResultManager resultManager = new DriverResultManager(driver);
        DriverSearchManager searchManager = new DriverSearchManager(driver);

        scraper.setResultManager(resultManager);
        scraper.setSearchManager(searchManager);

        scraper.search();
        scraper.getListOfProducts();
        driver.close();

        return resultManager.getProductList();

    }

    public void upload(int numToUpload) throws IOException {

        List<Product> products = getProducts();

        UMAlertAPI api = new UMAlertAPI();
        api.setApiManager(new APIRequestManager());

        for(int i=0;i<numToUpload; i++)
        {
            String json = products.get(i).stringify();
            api.postRequest(json);
        }
    }

    public void removeAll() throws IOException {
        UMAlertAPI api = new UMAlertAPI();
        api.setApiManager(new APIRequestManager());
        api.deleteRequest();

    }

    public void uploadOfType(int type) throws IOException {
        Product dummyProduct = new Product(type, "name", "desc", "url", "image", 100);

        UMAlertAPI api = new UMAlertAPI();
        api.setApiManager(new APIRequestManager());

        api.postRequest(dummyProduct.stringify());


    }

}
